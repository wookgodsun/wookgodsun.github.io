//클릭하면 속성을 추가하는 기능 구현 
//이렇게 하면 속한곳 아래의 공간에 추가되도록 설정할 수 있음.
function eduAddFunc(e){
    

    var edu_btn = document.querySelector('.edu');
    var result_edu = document.querySelector('.result-edu')

    var newinput1 = document.createElement("input");
    var newinput2 = document.createElement("input");
    var newinput3 = document.createElement("input");
    var newdiv1 = document.createElement('div');
    var newdiv2 = document.createElement('div');
    var newdiv3 = document.createElement('div');
    
    

    newinput1.setAttribute('placeholder','your education')
    newinput2.setAttribute('placeholder','your major')
    newinput3.setAttribute('placeholder','your duration')

    edu_btn.appendChild(newinput1);
    edu_btn.appendChild(newinput2);
    edu_btn.appendChild(newinput3);

    result_edu.appendChild(newdiv1);
    result_edu.appendChild(newdiv2);
    result_edu.appendChild(newdiv3);
    
    edu_btn.innerHTML += '<p>'
    result_edu.innerHTML += '<p>'
  
}

function expAddFunc(){

    var exp_btn = document.querySelector('.exp');
    var result_exp = document.querySelector('.result-exp')

    var newinput1 = document.createElement("input");
    var newinput2 = document.createElement("input");
    var newinput3 = document.createElement("input");
    var newdiv1 = document.createElement('div');
    var newdiv2 = document.createElement('div');
    var newdiv3 = document.createElement('div');
    


    newinput1.setAttribute('placeholder','your organization')
    newinput2.setAttribute('placeholder','your duties')
    newinput3.setAttribute('placeholder','your duration')

    exp_btn.appendChild(newinput1);
    exp_btn.appendChild(newinput2);
    exp_btn.appendChild(newinput3);

    result_exp.appendChild(newdiv1);
    result_exp.appendChild(newdiv2);
    result_exp.appendChild(newdiv3);
    
    exp_btn.innerHTML += '<p>'
    result_exp.innerHTML += '<p>'
      
}

function skillAddFunc(){
    var result_skill = document.querySelector('.result-skill');
    var skill_tbody_area = document.querySelector('.skl');

    result_skill.innerHTML +='<span></span>&nbsp;&nbsp;<span></span><br>'
    skill_tbody_area.innerHTML +=  '<tr><td><input type="text"  id="skl-name" placeholder="your skill"></td><td><input type="text"  id="skl-fluency" placeholder="your fluency"></td></tr>'
//innerHTML로 추가해도되는걸 appendCHild로 개 고생했었다..

}

function otherAddFunc(){
    var result_others = document.querySelector('.result-others')// 아웃풋쪽의 영역표시
    var others_fieldset_area = document.querySelector('.oth') //인풋쪽의 영역표시

    var newinput = document.createElement('input');
    newinput.setAttribute('placeholder','그외의 입력할만한 것들');

    var newdiv = document.createElement('div')

    others_fieldset_area.appendChild(newinput);
    result_others.appendChild(newdiv);

    others_fieldset_area.innerHTML += '<p>'
    result_others +='<p>'

}

//한번에 구현하는것은 너무 힘들기때문에 속해있는곳을 기준으로 구현하기로 결정.
// var btn = document.getElementsByClassName('btn');
// console.log(btn)

// for(let i=0; i<btn.length; i++){
//     btn[i].addEventListener('click',function(){
        
//     });
// }



//입력한대로 화면에  출력하기 
var firstname = document.querySelector('#firstname')
var lastname = document.querySelector('#lastname')
var result_firstname = document.querySelector('.result-firstname')
var result_lastname = document.querySelector('.result-lastname');

var information = document.querySelector('#information');
var goal = document.querySelector('#goal');
var result_information = document.querySelector('.result-information');
var result_goal = document.querySelector('.result-goal');


firstname.onkeyup = function(){
   result_firstname.innerHTML = this.value;
}
lastname.onkeyup = function(){
    result_lastname.innerHTML = this.value;
}
goal.onkeyup = function(){
    result_goal.innerHTML = this.value;
}
information.onkeyup = function(){
    result_information.innerHTML = this.value;
}




// 입력한 정보를 배열로 입력해서 출력하기
// window보다는 버튼을 눌렀을때 클릭이 되도록 해야하지만 임시방편으로.. 
window.addEventListener('click', function(){

    var edu = document.querySelectorAll(".edu input");
    var result_education = document.querySelectorAll(".result-edu div");
    
    for (let i=0 ; i<result_education.length; i++){
        edu[i].addEventListener('keyup',function(){
            result_education[i].innerHTML = '<li>'+this.value+'</li>';
        });
    } 

    var experience = document.querySelectorAll(".exp input");
    var result_experience = document.querySelectorAll('.result-exp div');

        for (let i = 0, len = result_experience.length; i < len; i++) {
            experience[i].addEventListener('keyup', function(){
                result_experience[i].innerHTML = '<li>'+this.value+'</li>';
            });
        }
        /*Object.keys(experience).map((i) => {
            experience[i].addEventListener('keypress', function(){
                result_experience[i].innerText = this.value;    
            });
        }); */
    var result_others_output_div_area = document.querySelectorAll('.result-others div');
    var others_fieldset_input_area = document.querySelectorAll('.oth input');



    for(let i=0; i<result_others_output_div_area.length; i++){
        // console.log(i) 여기 i가 증가하는속도랑 아래의 i랑 속도가 다른듯하다.
        others_fieldset_input_area[i].addEventListener('keyup',function(){
            // console.log(i)
            // console.log(others_fieldset_input_area[i])
            result_others_output_div_area[i].innerHTML = '<li>'+this.value+'</li>';
            
        });
    }

    var result_skill_output_span_area = document.querySelectorAll('.result-skill span');
    var skill_tbody_input_area = document.querySelectorAll('.skl input')
    console.log(skill_tbody_input_area);

    for(let i=0; i<result_skill_output_span_area.length;i++){
        skill_tbody_input_area[i].addEventListener('keyup',function(){
            console.log(i)
            result_skill_output_span_area[i].innerHTML=this.value;
        });
    }
    
    }); 




//이미지 미리보기로 업로드 
var uploadfiles = document.querySelector('#uploadfiles')
uploadfiles.onchange = function(e){
    var fileReader = new FileReader()
    fileReader.onload = function(e){
        document.querySelector('.result-img').src = e.target.result;
    }
    fileReader.readAsDataURL(e.target.files[0])
    }

// css 속성 변화
// 25가 아니라 누를수록 커지게 만들어도 될것같긴함. 
var right_box = document.querySelector('.right-box');

function fontsizeupfunc(){
    // document.querySelector('.right-box').style.fontSize += "1px";    
    //점차 커지게 하려고 했으나 안먹는듯?
    document.querySelector('.right-box').style.fontSize = "25px";

}
function fontsizedownfunc(){
    document.querySelector('.right-box').style.fontSize = "15px";    
}

function fontWeightBold(){
    document.querySelector('.right-box').style.fontWeight ="bold";
}

function fontWeightNormal(){
    document.querySelector('.right-box').style.fontWeight ="normal";
}
function fontStyleItalic(){
     document.querySelector('.right-box').style.fontStyle ="italic";
}
function fontColor(){
    document.querySelector('.right-box').style.color ="pink";
}
function blinking(){   
        setInterval(function() {
           right_box.style.display = (right_box.style.display == 'none' ? '' : 'none');
        }, 300);
}
function underline(){
    right_box.style.textDecoration ="underline";
}
function resetCSS(){
    right_box.removeAttribute('style')
}
function changeBackground(){
    right_box.style.backgroundColor = 'gray';
    right_box.style.color = 'white';
}

    //입력한 정보를 다운로드받기

function createHTMLDocument() {
    var blob = new Blob(
        ['<!doctype html>',
        '<html><head><title>Resume</title><body>',
        document.querySelector('firstname').value,
        document.querySelector('lastname').value,
        '<hr>',
        
        '</body></html>'],
        {type:'text/html'}
    );
    var url = URL.createObjectURL(blob);
    var link = document.querySelector('link');
    
    link.setAttribute('href', url);
    link.innerHTML = '클릭하여 다운받기';
}
              